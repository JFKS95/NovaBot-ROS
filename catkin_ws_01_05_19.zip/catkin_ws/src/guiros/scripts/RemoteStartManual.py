import paramiko
import time


def run():
  ssh = paramiko.SSHClient()
  ssh.load_system_host_keys()
  ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
  ssh.connect(hostname='TriTrackPi', username='pi', password='milkyway')

  (ssh_stdin, ssh_stdout, ssh_stderr) = ssh.exec_command("python3 /home/pi/Tri-Track_Arm_Manual_Master.py")
  print("running manual")
def kill():

  ssh = paramiko.SSHClient()
  ssh.load_system_host_keys()
  ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
  ssh.connect(hostname='TriTrackPi', username='pi', password='milkyway')

  (ssh_stdin, ssh_stdout, ssh_stderr) = ssh.exec_command("python3 /home/pi/End_Tri_Track_Script.py")
  print("stopping manual")

##channel = ssh.invoke_shell()
##channel.send("rosrun")
##ssh.close()

##for line in ssh_stdout.readlines():
##  print(line)
##
##
##for line in ssh_stderr.readlines():
##  print(line)

if __name__ == "__run__":

  run()

if __name__ == "__kill__":

  kill()
