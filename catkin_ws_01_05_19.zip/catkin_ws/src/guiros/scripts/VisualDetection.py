from __future__ import print_function
import sys, os
sys.path.insert(0, '/usr/local/lib/python2.7/dist-packages')
import cv2
from random import randint
import math, numpy as np

import os, tensorflow as tf, imutils, time
sys.path.insert(0, '/home/team-g/Galaxy Solutions Code/ObjectDetection_try2/tf_ModelsMaster_protobuf/models/research')
sys.path.insert(0, '/home/team-g/Galaxy Solutions Code/ObjectDetection_try2/tf_ModelsMaster_protobuf/models/research/object_detection')
from utils import label_map_util
from utils import visualization_utils as vis_util

# GLOBAL VARIABLES
stageRunFirstTime = 1  # used to identify if stage is running for the first time
detectionStage = 1  # automated object detection
trackingStage = 0   # automated tracking stage
manualROI = 0       # manual ROI selection
errorCodeStage = 0  # visual error code detection 
shutdownPuck = 0    # shutting down puck in correct shutdown zone

def nothing(x):
    pass

def run():
    # GLOBAL VARIABLES
    global detectionStage, trackingStage, manualROI, errorCodeStage, stageRunFirstTime, shutdownPuck
    # LOCAL VARIABLES
    bboxesRaw = []  # for collecting boxes from detection stage into useable state
    bboxes = []     # for multi tracking
    colours = []    # for drawing different coloured boxes
    
    # DOWNLOADING OBJECT DETECTION MODELS -------------------------------------------------------------
    print('Automated ROI Detected Stage ...')
    
    # First download the model
    print('downloading Puck detection model...')

    # Object detection folder location
    PARENT_FOLDER = '/home/team-g/Galaxy Solutions Code/ObjectDetection_try2/tf_ModelsMaster_protobuf/models/research/object_detection'
    # Model Folder Location
    MODEL_NAME = PARENT_FOLDER + '/current_PuckModel'

    # Path to frozen detection graph. Actual model that is used for the object detection
    PATH_TO_CKPT = MODEL_NAME + '/frozen_inference_graph.pb'

    # List of the strings that is used to add correct label for each box
    PATH_TO_LABELS = os.path.join(PARENT_FOLDER + '/training', 'puck_label.pbtxt')
    NUM_CLASSES = 1 # only PUCK being detected

    # loading the frozen tensorflow model into memory 
    detection_graph = tf.Graph()
    with detection_graph.as_default():
        od_graph_def = tf.GraphDef()
        with tf.gfile.GFile(PATH_TO_CKPT, 'rb') as fid:
            serialized_graph = fid.read()
            od_graph_def.ParseFromString(serialized_graph)
            tf.import_graph_def(od_graph_def, name='')
            
    # loading the label map
    label_map = label_map_util.load_labelmap(PATH_TO_LABELS)
    categories = label_map_util.convert_label_map_to_categories(label_map, max_num_classes=NUM_CLASSES, use_display_name=True)
    category_index = label_map_util.create_category_index(categories)
    print('model downloaded...')
    # model is now downloaded into memory, can begin detection
    # END OF OBJECT DETECTION MODEL DOWNLOAD

    
    # initialise video capture
    cap = cv2.VideoCapture(0)
    print('Starting video stream...')

    # maximum number of detections allowed 
    detection_limit = 3
    
    with detection_graph.as_default():
        with tf.Session(graph=detection_graph) as sess:
            while True:
                key = cv2.waitKey(25) & 0xFF
                # reading current frame
                success, frame = cap.read()
                if not success:
                    print('Lost connection with video stream, exitting program ...')
                    sys.exit()
                
                # PUCK DETECTION STAGE ----------------------------------------------------------------
                if detectionStage == 1:
                    if stageRunFirstTime == 1:
                        print('Automated Puck Detection Stage') 
                        stageRunFirstTime = 0
                    # expand dimension since the model expects images to have shape: [1, None, None, 3]
                    frame_expanded = np.expand_dims(frame, axis=0)

                    image_tensor = detection_graph.get_tensor_by_name('image_tensor:0')
                    # Each box represents a part of the image where a particular object was detected.
                    boxes = detection_graph.get_tensor_by_name('detection_boxes:0')
                    # Each score represents the level of confidence for the detected objects
                    scores = detection_graph.get_tensor_by_name('detection_scores:0')
                    classes = detection_graph.get_tensor_by_name('detection_classes:0')
                    num_detections = detection_graph.get_tensor_by_name('num_detections:0')

                    # Puck Detection here
                    # drawing found boxes
                    (boxes, scores, classes, num_detections) = sess.run(
                        [boxes, scores, classes, num_detections],
                        feed_dict={image_tensor: frame_expanded})
                    # visualisation of results
                    vis_util.visualize_boxes_and_labels_on_image_array(
                        frame,
                        np.squeeze(boxes),
                        np.squeeze(classes).astype(np.int32),
                        np.squeeze(scores),
                        category_index,
                        use_normalized_coordinates=True,
                        line_thickness=8)
                    
                    # boxes defined here
                    xmin = []
                    xmax = []
                    ymin = []
                    ymax = []
                    width = []
                    height = []
                    for detected in boxes[0]:
                            xmin = np.append(xmin, detected[1]*640)
                            xmax = np.append(xmax, detected[3]*640)
                            ymin = np.append(ymin, detected[0]*480)
                            ymax = np.append(ymax, detected[2]*480)
                    width = np.subtract(xmax, xmin)
                    height = np.subtract(ymax, ymin)
                    
                    #bboxes = np.array(xmin, ymin, width, height)
                    #print(bboxes)
                    # need to make scores reject some of the results. Not sure how to do this yet though.
                    
                    # END OF DETECTION
                    
                    # enter Tracking stage
                    if key == ord('t'):
                        trackingStage = 1
                        detectionStage = 0
                        errorCodeStage = 0
                        stageRunFirstTime = 1
                        print(xmin, ymin, width, height)
                                                
                        
                    # enter Manual ROI stage
                    if key == ord('m'):
                        manualROI = 1
                        detectionStage = 0
                        errorCodeStage = 0
                        stageRunFirstTime = 1
                        bbox = []
                        bboxes = []
                        
                    
                    # putting text onto the frame
                    if detectionStage == 1:
                        cv2.putText(frame,'Automated Puck Detection Stage',(30,50),cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,255),2)
                        cv2.putText(frame,'"t" to enter Tracking Stage with detected ROI(s)',(30,70),cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,255),2)
                        cv2.putText(frame,'"m" to manually select ROI',(30,90),cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,255),2)

                # END OF PUCK DETECTION -----------------------------------------------------------


                # MANUAL ROI SELECTION ------------------------------------------------------------
                if manualROI == 1:
                    if stageRunFirstTime == 1:
                        print('Manual ROI Selection Stage')
                        stageRunFirstTime = 0

                    while True:
                        cv2.putText(frame,'[space] to confirm selection followed by:',(30,50),cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,255),2)
                        cv2.putText(frame,'[any] to select another ROI',(30,70),cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,255),2)
                        cv2.putText(frame,'"t" to confirm selections and continue to tracking',(30,90),cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,255),2)
                        cv2.putText(frame,'"a" to return to Automated Puck Detection stage',(30,110),cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,255),2)
                        bbox = cv2.selectROI('Select Region of Interest', frame)

                        bboxes.append(bbox)
                        colours.append((randint(64, 255), randint(64, 255), randint(64, 255)))
                        key = cv2.waitKey(0) & 0xFF
                        if key == ord('t'):
                            cv2.destroyWindow('Select Region of Interest')
                            print('Selected bounding boxes {}'.format(bboxes))
                            stageRunFirstTime = 1
                            detectionStage = 0  
                            trackingStage = 1
                            errorCodeStage = 0
                            manualROI = 0
                            break
                        
                        elif key == ord('a'):
                            cv2.destroyWindow('Select Region of Interest')                           
                            print('Selected bounding boxes {}'.format(bboxes))
                            stageRunFirstTime = 1
                            detectionStage = 1  
                            trackingStage = 0
                            errorCodeStage = 0
                            manualROI = 0
                            break
                
                # END OF MANUAL ROI SELECTION STAGE --------------------------------------------------

                # PUCK TRACKING STAGE ----------------------------------------------------------------
                if trackingStage == 1:
                    if stageRunFirstTime == 1:
                        print('Puck Tracking Stage')
                        stageRunFirstTime = 0
                        # create multi tracker object
                        multiTracker = cv2.MultiTracker_create()
                        # initialise multitracker
                        for bbox in bboxes:
                            multiTracker.add(cv2.TrackerCSRT_create(), frame, bbox)
                     
                    # PUCK TRACKING HERE
                    # tracker updated for current frame (might need to do pass this it for the very first loop iteration
                    success, boxes = multiTracker.update(frame)
                    # drawing boxes for visualisation of tracked objects
                    for i, newbox in enumerate(boxes):
                        p1 = (int(newbox[0]), int(newbox[1]))
                        p2 = (int(newbox[0] + newbox[2]), int(newbox[1] + newbox[3]))
                        cv2.rectangle(frame, p1, p2, colours[i], 2, 1)
                    # END OF PUCK TRACKING

                    # return to Manual ROI Stage                           
                    if key == ord('m'):
                        stageRunFirstTime = 1
                        detectionStage = 0  
                        trackingStage = 0  
                        manualROI = 1
                        errorCodeDetection = 0

                    # return to Puck detection stage
                    if key == ord('a'):
                        stageRunFirstTime = 1
                        detectionStage = 1  
                        trackingStage = 0  
                        manualROI = 0
                        errorCodeDetection = 0

                    # enter error code detection stage
                    if key == ord('e'):
                        stageRunFirstTime = 1
                        detectionStage = 0  
                        trackingStage = 0
                        errorCodeStage = 1
                        manualROI = 0

                    if trackingStage == 1:
                        cv2.putText(frame,'Puck Tracking Stage',(30,50),cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,255),2)
                        cv2.putText(frame,'"a" to return to Automated Puck Detection Stage',(30,70),cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,255),2)
                        cv2.putText(frame,'"m" to select manual ROI(s)',(30,90),cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,255),2)
                        cv2.putText(frame,'"e" to run visual error code detection',(30,110),cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,255),2)
                # END OF PUCK TRACKING STAGE------------------------------------------------------------

                # ERROR CODE DETECTION ---------------------------------------------------------------
                if errorCodeStage == 1:
                    if stageRunFirstTime == 1:
                        print('Error Code Detection Stage')
                        stageRunFirstTime = 0

                    # ERROR CODE DETECTION HERE


                    if key == ord('n'):
                        print('iterating to next ROI')
                    # END OF CODE DETECTION
                    # return to Manual ROI Stage
                    if key == ord('m'):
                        stageRunFirstTime = 1
                        detectionStage = 0  
                        trackingStage = 0
                        errorCodeStage = 0
                        manualROI = 1

                    # return to Puck detection stage
                    if key == ord('a'):
                        stageRunFirstTime = 1
                        detectionStage = 1  
                        trackingStage = 0
                        errorCodeStage = 0
                        manualROI = 0
                        
                    # shutdown Selected Puck Stage
                    if key == ord('s'):
                        stageRunFirstTime = 1
                        detectionStage = 0  
                        trackingStage = 0
                        errorCodeStage = 0
                        shutdownPuck = 1
                        manualROI = 0                        

                    if errorCodeStage == 1:
                        cv2.putText(frame,'Error Code Detection Stage',(30,50),cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,255),2)
                        cv2.putText(frame,'"a" to return to Automated Puck Detection Stage',(30,70),cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,255),2)
                        cv2.putText(frame,'"m" to select manual ROI(s)',(30,90),cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,255),2)
                        cv2.putText(frame,'"n" to iterate to the next ROI',(30,110),cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,255),2)
                        cv2.putText(frame,'"s" to accept Error Code and exit to shutdown selected Puck in correct zone',(30,130),cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,255),2)                    
                                                        
                # END OF ERROR CODE DETECTION ---------------------------------------------------------

                # SHUTDOWN PUCK STAGE -----------------------------------------------------------------
                if shutdownPuck == 1:
                    if stageRunFirstTime == 1:
                        print('Shutting down selected Puck in correct zone')
                        stageRunFirstTime = 0

                    # PUCK SHUTDOWN

                    # END OF SHUTDOWN

                    if shutdownPuck == 1:
                        cv2.putText(frame,'Shutting down selected Puck',(30,50),cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,255),2)
                        cv2.putText(frame,'"q" to prematurely exit program',(30,70),cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,255),2)
                # END OF SHUTDOWN PUCK STAGE ----------------------------------------------------------

                cv2.imshow('Live Video Feed', frame)
                if key == ord('q'):
                    break
                
    cv2.destroyAllWindows()
##    sys.exit()
    cap.release()
    visualErrorCode = "V001"
    return(visualErrorCode)


if __name__ == "__run__":
    run()
##run()
