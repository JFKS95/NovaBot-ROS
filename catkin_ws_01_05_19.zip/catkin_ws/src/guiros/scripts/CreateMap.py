import sys
sys.path.insert(0,'/usr/local/lib/python2.7/dist-packages')
import cv2, numpy as np

def make_480p(cap):
  cap.set(3,640)
  cap.set(4,480)

def run():
  # setting up camera
  cap = cv2.VideoCapture(0)

  make_480p(cap)

  ZoneA = None
  ZoneB = None


  # initialise tracker
  print("starting video stream")

  while(True):
    # Capture frame
    ret, frame = cap.read()

    # define key presses for commands later in script
    key = cv2.waitKey(1) & 0xFF

    # capture resolution for later use in script
    resolution = np.shape(frame)
    ymax, xmax,_ = resolution

    # Write Text instructions
    font = cv2.FONT_HERSHEY_SIMPLEX
    topLeftCorner = (10,40)
    text2 = (10,60)
    fontScale = 0.8
    fontColor = (255,255,255)
    lineType = 2
    # filter out yellow and green and black here using colourspace -----------------------


    # ---------------------------
    # canny edge detect
    edges = cv2.Canny(frame,200,250)

    # if zones exist, then remove this part of the image from canny edge detect
    if ZoneA and ZoneB and ZoneM is not None:
      # create image of white with black zone squares (will be inverted later)
      mask = np.zeros(np.shape(edges), dtype=np.uint8)
      mask.fill(255)
      cv2.rectangle(mask,(xA,yA),(xA+wA,yA+hA),(0,0,0),-1)
      cv2.rectangle(mask,(xB,yB),(xB+wB,yB+hB),(0,0,0),-1)
      cv2.rectangle(mask,(xM,yM),(xM+wM,yM+hM),(0,0,0),-1)
      # BITWISE-AND this mask and the canny edge detected image
      edges = cv2.bitwise_and(mask, edges)
      edges = np.invert(edges)
    else:
      edges = np.invert(edges)    

    # click c, to export map of Canny Edge detected image
    if key == ord('c'):
      # export image Shehroz's mapping    
      # inverted for Sheroz
      cv2.imwrite('/home/team-g/catkin_ws/src/provide_map/map/PUCKWANK.jpg', np.invert(edges))
      cv2.imshow('image',edges)

    
    # ------------------------------------------------------------------------------------
    # ------------------------------------------------------------------------------------    
    # click z, to choose zones 
    if key == ord('z'):
      ZoneA = cv2.selectROI('SelectingZones', frame)
      xA, yA, wA, hA = ZoneA
##      print(ZoneA)

      ZoneB = cv2.selectROI('SelectingZones', frame)
      xB, yB, wB, hB = ZoneB
##      print(ZoneB)

      ZoneM = cv2.selectROI('SelectingZones', frame)
      xM, yM, wM, hM = ZoneM
##      print(ZoneM)

      cv2.destroyWindow('SelectingZones')
      print('zones selected')
    # if zone has been chosen then draw onto frame for visualisation  
    if ZoneA and ZoneB and ZoneM is not None:
      cv2.rectangle(frame,(xA,yA),(xA+wA,yA+hA),(0,255,0),2)
      cv2.rectangle(frame,(xB,yB),(xB+wB,yB+hB),(0,255,0),2)
      cv2.rectangle(frame,(xM,yM),(xM+wM,yM+hM),(255,0,0),2)
      # to adjust for coordinate differences between rviz and opencv
      xA_s = str((xA+wA/2))
      yA_s = str(ymax-(yA+hA/2))
      xB_s = str((xA+wA/2))
      yB_s = str(ymax-(yA+hA/2))
      xM_s = str((xA+wA/2))
      yM_s = str(ymax-(yA+hA/2))
      cv2.putText(frame, '"c" to capture maze',
                  topLeftCorner,
                  font,
                  fontScale,
                  fontColor,
                  lineType)
      cv2.putText(frame, '"q" to exit',
                  text2,
                  font,
                  fontScale,
                  fontColor,
                  lineType)
      
      
    else: # Zones not chosen yet
      cv2.putText(frame, '"z" to choose Zones',
                  topLeftCorner,
                  font,
                  fontScale,
                  fontColor,
                  lineType)
      cv2.putText(frame, '"q" to exit',
                  text2,
                  font,
                  fontScale,
                  fontColor,
                  lineType)
      

    cv2.imshow('Live Video Stream', frame)
    # ------------------------------------------------------------------------------------
    # ------------------------------------------------------------------------------------
         
    # Option to exit Video Capture
    if key == ord('q'):
      break
  
  
  cap.release()
  cv2.destroyAllWindows()
  return(ZoneA, ZoneB, ZoneM)

if __name__ == "__run__":
  run()
##run()
