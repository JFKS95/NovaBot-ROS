#!/usr/bin/python
#
# Copyright 2018 BIG VISION LLC ALL RIGHTS RESERVED
# 
from __future__ import print_function
import sys
sys.path.insert(0,'/usr/local/lib/python2.7/dist-packages')
import cv2
from random import randint
import math
import numpy as np

trackerTypes = ['BOOSTING', 'MIL', 'KCF','TLD', 'MEDIANFLOW', 'GOTURN', 'MOSSE', 'CSRT']
trackerType = "CSRT"

def run():
  # Define camera matrix K
  K = np.array([[311.59349149, 0., 296.62355791],
                [0., 309.57966106, 263.05200968],
               [0., 0., 1.]])
  # Define distortion coefficients d
  d = np.array([0.03080295, -0.08277161, -0.00200696, 0.00031356,  0.03151164])

  


    # Create a video capture object to read videos
  cap = cv2.VideoCapture(0)

  while True:

    # Read first frame
    success, frame = cap.read()

    ## start of undistortion
    img = frame
    h, w = img.shape[:2]
    # Generate new camera matrix from parameters
    newcameramatrix, roi = cv2.getOptimalNewCameraMatrix(K, d, (w,h), 0)

    # Generate look-up tables for remapping the camera image
    mapx, mapy = cv2.initUndistortRectifyMap(K, d, None, newcameramatrix, (w, h), 5)

    # Remap the original image to a new image
    newimg = cv2.remap(img, mapx, mapy, cv2.INTER_LINEAR)
    frame = newimg
    ## end of undistortion

    resolution = np.shape(frame)
    ymax, xmax,_ = resolution
    # quit if unable to read the video file
    if not success:
      print('Failed to read video')
      sys.exit(1)

    ## Select boxes
    bboxes = []
    colors = [] 

    # OpenCV's selectROI function doesn't work for selecting multiple objects in Python
    # So we will call this function in a loop till we are done selecting all objects
    while True:
      # draw bounding boxes over objects
      # selectROI's default behaviour is to draw box starting from the center
      # when fromCenter is set to false, you can draw box starting from top left corner
      bbox = cv2.selectROI('MultiTracker', frame)
      bboxes.append(bbox)
      colors.append((randint(64, 255), randint(64, 255), randint(64, 255)))
      print("Press q to quit selecting boxes and start tracking")
      print("Press any other key to select next object")
      k = cv2.waitKey(0) & 0xFF
      if (k == 113):  # q is pressed
        break
    
    print('Selected bounding boxes {}'.format(bboxes))

    ## Initialize MultiTracker
    # There are two ways you can initialize multitracker
    # 1. tracker = cv2.MultiTracker("CSRT")
    # All the trackers added to this multitracker
    # will use CSRT algorithm as default
    # 2. tracker = cv2.MultiTracker()
    # No default algorithm specified

    # Initialize MultiTracker with tracking algo
    # Specify tracker type
    
    # Create MultiTracker object
    multiTracker = cv2.MultiTracker_create()

    # Initialize MultiTracker 
    for bbox in bboxes:
      multiTracker.add(createTrackerByName(trackerType), frame, bbox)
     


    # Process video and track objects
    while cap.isOpened():
      success, frame = cap.read()
      if not success:
        break
      
      # get updated location of objects in subsequent frames
      success, boxes = multiTracker.update(frame)

      # draw tracked objects
      for i, newbox in enumerate(boxes):
        p1 = (int(newbox[0]), int(newbox[1]))
        p2 = (int(newbox[0] + newbox[2]), int(newbox[1] + newbox[3]))
        cv2.rectangle(frame, p1, p2, colors[i], 2, 1)

      # ANGLES
      x1, y1, w1, h1 = boxes[0]
      x2, y2, w2, h2 = boxes[1]
      centreAx = x1+(w1/2)
      centreAy = y1+(h1/2)
      centreBx = x2+(w2/2)
      centreBy = y2+(h2/2)
      
      distX = centreBx - centreAx
      distY = centreBy - centreAy
      angleRad = math.atan(distY/distX)
      angleDeg = math.degrees(angleRad)
      angleDegA = abs(angleDeg)
      
      # Top right 
      if distX > 0 and distY <= 0:
        angle = angleDegA
      # Top left
      elif distX <= 0 and distY <= 0:
        angle = 180-angleDegA
      # Bottom Left
      elif distX <= 0 and distY > 0:
        angle = 180+angleDegA
      #Bottom Right
      elif distX > 0 and distY > 0:
        angle = 360-angleDegA

      #print(angle)
      angleRad = math.radians(angle)

      # TriTrack Location (centre of two points)
      centreTx = (centreAx + centreBx)/2
      centreTy = (centreAy + centreBy)/2

      # Sending Angle
      targetFile = open('/home/team-g/catkin_ws/src/simple_navigation_goals/src/TriTrackTheta.txt','w')
      targetFile.write(str(angleRad))
      targetFile.close()
      # Sending TriTrack Location
      centreTy = ymax - centreTy 
      targetFile = open('/home/team-g/catkin_ws/src/ros_dom/src/TriTrackLoc.txt','w')
      targetFile.write(str(centreTx) + '\n' + str(centreTy))
      targetFile.close()
      
      # show frame
      cv2.imshow('MultiTracker', frame)
      

      # quit on ESC button
      if cv2.waitKey(1) & 0xFF == ord('q'):  # Esc pressed
        break
    break
  cv2.destroyAllWindows()
  cap.release()



  
def createTrackerByName(trackerType):
  # Create a tracker based on tracker name
  if trackerType == trackerTypes[0]:
    tracker = cv2.TrackerBoosting_create()
  elif trackerType == trackerTypes[1]: 
    tracker = cv2.TrackerMIL_create()
  elif trackerType == trackerTypes[2]:
    tracker = cv2.TrackerKCF_create()
  elif trackerType == trackerTypes[3]:
    tracker = cv2.TrackerTLD_create()
  elif trackerType == trackerTypes[4]:
    tracker = cv2.TrackerMedianFlow_create()
  elif trackerType == trackerTypes[5]:
    tracker = cv2.TrackerGOTURN_create()
  elif trackerType == trackerTypes[6]:
    tracker = cv2.TrackerMOSSE_create()
  elif trackerType == trackerTypes[7]:
    tracker = cv2.TrackerCSRT_create()
  else:
    tracker = None
    print('Incorrect tracker name')
    print('Available trackers are:')
    for t in trackerTypes:
      print(t)
    
  return tracker

if __name__ == "__run__":
  run()

#run()
