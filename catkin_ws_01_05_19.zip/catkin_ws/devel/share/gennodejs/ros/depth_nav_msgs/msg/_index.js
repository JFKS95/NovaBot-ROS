
"use strict";

let Point32List = require('./Point32List.js');

module.exports = {
  Point32List: Point32List,
};
