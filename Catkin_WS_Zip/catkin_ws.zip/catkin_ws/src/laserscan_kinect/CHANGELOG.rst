^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package laserscan_kinect
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.1 (2016-11-11)
------------------
* Support for depthmaps with float32 encoding

1.0.0 (2016-01-01)
------------------
* Fix dynamic reconfigure bug associated with config header generation
* Attempt to fix dynamic reconfigure bug
* Dynamic configuration file update
* Add package laserscan_kinect to depth_nav_tools metapackage
* Contributors: Michal Drwiega
