void vcos(void) {
}
