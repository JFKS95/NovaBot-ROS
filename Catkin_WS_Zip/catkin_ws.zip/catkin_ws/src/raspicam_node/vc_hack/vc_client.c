void vc_client(void) {
}
